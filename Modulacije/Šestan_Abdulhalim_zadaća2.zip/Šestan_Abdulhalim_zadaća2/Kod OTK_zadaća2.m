close all
clear all
clc

Rb=100e3; 
A=2.05;
B=65;
delt=0.035;
l=2.5;
fc=1e6;
fs=2e6;
Tb=1/Rb;
Amp=2.5;
Nb=10;
SNR = [1,5,10,15,20];
fill = round(fs/Rb);

b=round(rand(1,Nb));
NRZ=[];
MANCH=[];

for i=1:Nb
    if b(i)==0
        NRZ=[NRZ -Amp.*ones(1,fill)];
        MANCH=[MANCH -Amp.*ones(1,fill/2) Amp.*ones(1,fill/2)];
    else
        NRZ=[NRZ Amp.*ones(1,fill)];
        MANCH=[MANCH Amp.*ones(1,fill/2) -Amp.*ones(1,fill/2)];
    end
end

figure(1)
subplot(2,1,1)
plot(NRZ)
title('NRZ kod')
subplot(2,1,2)
plot(MANCH)
title('Manchester kod')

f=0:100:fs;
b_dio = 1i.*B.*(f./fc);
a_dio = A .* sqrt(f./fc);
zag_dio = (1i.*(delt./2));
gama = (1-zag_dio).*(a_dio+b_dio);
H=exp(-gama.*l);
h_kanal=fir2(10,f./2e6,abs(H));

izlaz1 = conv(NRZ,h_kanal);
izlaz2 = conv(MANCH,h_kanal);

figure(2)
subplot(2,1,1)
plot(izlaz1)
title('NRZ signal nakon prolaska kroz kanal')
subplot(2,1,2)
plot(izlaz2)
title('Manchester signal nakon prolaska kroz kanal')

n=1;
out1=ones(length(SNR),length(izlaz1));
out2=ones(length(SNR),length(izlaz2));
while n<=length(SNR)
    out1(n,:)=awgn(izlaz1,SNR(n));
    out2(n,:)=awgn(izlaz2,SNR(n));
    n=n+1;
end

figure(3)
subplot(5,1,1)
plot(out1(1,:));
title('NRZ signal poslije djelovanja AWGN-1dB')
subplot(5,1,2)
plot(out1(2,:));
title('NRZ signal poslije djelovanja AWGN-5dB')
subplot(5,1,3)
plot(out1(3,:));
title('NRZ signal poslije djelovanja AWGN-10dB')
subplot(5,1,4)
plot(out1(4,:));
title('NRZ signal poslije djelovanja AWGN-15dB')
subplot(5,1,5)
plot(out1(5,:));
title('NRZ signal poslije djelovanja AWGN-20dB')

figure(4)
subplot(5,1,1)
plot(out2(1,:));
title('Manchester signal poslije djelovanja AWGN-1dB')
subplot(5,1,2)
plot(out2(2,:));
title('Manchester signal poslije djelovanja AWGN-5dB')
subplot(5,1,3)
plot(out2(3,:));
title('Manchester signal poslije djelovanja AWGN-10dB')
subplot(5,1,4)
plot(out2(4,:));
title('Manchester signal poslije djelovanja AWGN-15dB')
subplot(5,1,5)
plot(out2(5,:));
title('Manchester signal poslije djelovanja AWGN-20dB')

h1_t = ones(1,fill);
h2_t = [-ones(1,fill/2) ones(1,fill/2)];
y1=ones(length(SNR),length(out1));
y2=ones(length(SNR),length(out2));

for i=1:length(SNR)
    y1(i,:) = conv(out1(i,:),h1_t,'same');
    y2(i,:) = conv(out2(i,:),h2_t,'same');
end

figure(5)
subplot(5,1,1)
plot(y1(1,:));
title('NRZ signal sa AWGN(1dB) nakon optimalnog filtera')
subplot(5,1,2)
plot(y1(2,:));
title('NRZ signal sa AWGN(5dB) nakon optimalnog filtera')
subplot(5,1,3)
plot(y1(3,:));
title('NRZ signal sa AWGN(10dB) nakon optimalnog filtera')
subplot(5,1,4)
plot(y1(4,:));
title('NRZ signal sa AWGN(15dB) nakon optimalnog filtera')
subplot(5,1,5)
plot(y1(5,:));
title('NRZ signal sa AWGN(20dB) nakon optimalnog filtera')

figure(6)
subplot(5,1,1)
plot(y2(1,:));
title('Manchester signal sa AWGN(1dB) nakon optimalnog filtera')
subplot(5,1,2)
plot(y2(2,:));
title('Manchester signal sa AWGN(5dB) nakon optimalnog filtera')
subplot(5,1,3)
plot(y2(3,:));
title('Manchester signal sa AWGN(10dB) nakon optimalnog filtera')
subplot(5,1,4)
plot(y2(4,:));
title('Manchester signal sa AWGN(15dB) nakon optimalnog filtera')
subplot(5,1,5)
plot(y2(5,:));
title('Manchester signal sa AWGN(20dB) nakon optimalnog filtera')

for i=1:length(SNR);
    for k=1:length(y1)
        if y1(i,k)>1
            y1(i,k)=Amp;
        elseif y1(i,k)<-1
            y1(i,k)=-Amp;
        else
             y1(i,k)=0;
        end
    end
end

for i=1:length(SNR);
    for k=1:length(y2)
        if y2(i,k)>1
            y2(i,k)=Amp;
        elseif y2(i,k)<-1
            y2(i,k)=-Amp;
        else
             y2(i,k)=0;
        end
    end
end

figure(7)
subplot(5,1,1)
plot(y1(1,:));
title('NRZ signal sa AWGN(1dB) poslije detektora')
subplot(5,1,2)
plot(y1(2,:));
title('NRZ signal sa AWGN(5dB) poslije detektora')
subplot(5,1,3)
plot(y1(3,:));
title('NRZ signal sa AWGN(10dB) poslije detektora')
subplot(5,1,4)
plot(y1(4,:));
title('NRZ signal sa AWGN(15dB) poslije detektora')
subplot(5,1,5)
plot(y1(5,:));
title('NRZ signal sa AWGN(20dB) poslije detektora')

figure(8)
subplot(5,1,1)
plot(y2(1,:));
title('Manchester signal sa AWGN(1dB) poslije detektora')
subplot(5,1,2)
plot(y2(2,:));
title('Manchester signal sa AWGN(5dB) poslije detektora')
subplot(5,1,3)
plot(y2(3,:));
title('Manchester signal sa AWGN(10dB) poslije detektora')
subplot(5,1,4)
plot(y2(4,:));
title('Manchester signal sa AWGN(15dB) poslije detektora')
subplot(5,1,5)
plot(y2(5,:));
title('Manchester signal sa AWGN(20dB) poslije detektora')

b_NRZ=zeros(length(SNR),Nb);
b_MANCH=zeros(length(SNR),Nb);
n=1;
while n<=length(SNR)
    k=fill/2;
    s=1;
    while k<=length(y1)
        if y1(n,k)==Amp
            b_NRZ(n,s) = 1;
        else
            b_NRZ(n,s) = 0; 
        end
        s=s+1;
        k=k+fill;
    end
    n=n+1;
end

for n=1:length(SNR);
    k=fill/2;
    s=1;
    while k<=length(y2)
        if y2(n,k)==Amp
            b_MANCH(n,s) = 1;
        else
            b_MANCH(n,s) = 0; 
        end
        k=k+fill;
        s=s+1;
    end
end

br_NRZ=zeros(length(SNR),1);
for i=1:length(SNR)
    for k=1:Nb
        if b_NRZ(i,k)~= b(1,k)
            br_NRZ(i,1) = br_NRZ(i,1)+1;
        else
            br_NRZ(i,1) = br_NRZ(i,1);
        end
    end
end

br_MANCH=zeros(length(SNR),1);
for i=1:length(SNR)
    for k=1:Nb
        if b_MANCH(i,k)~=b(1,k)
            br_MANCH(i,1) = br_MANCH(i,1)+1;
        else
            br_MANCH(i,1) = br_MANCH(i,1);
        end
    end
end

Vjgres_NRZ=br_NRZ./Nb;
Vjgres_MANCH=br_MANCH./Nb;

snr=10.^(SNR/10);
Bend=1/Tb;
x=snr.*Bend./Rb;

figure(9)
subplot(2,1,1)
plot(10*log(x),Vjgres_NRZ)
title('Vjerovatnoca greske za NRZ kod')
subplot(2,1,2)
plot(10*log(x),Vjgres_MANCH)
title('Vjerovatnoca greske za Manchester kod')