close all;
clear all;
clc;

f1 = 10;
f2 = 15;
f3 = 20;

fmax = max([f1 f2 f3]);
fs = 50*fmax;
Ts = 1/fs;
Tend = 0.35;

t = 0:Ts:Tend;

x = 0.4*sin(2*pi*f1*t + 0.2) + 0.3*cos(2*pi*f2*t) - 0.5*sin(2*pi*f3*t + 0.5);

figure;
plot(t,x);
grid on;
xlabel('t (s)'); 
ylabel('x(t)');
title('Ulazni signal');

xi = 0;
for n = 1:length(x)
if n == 1
e(n) = x(n);
else
e(n) = x(n) - xm(n-1);
end


xi = xi + e(n);


if xi >= 0
xm(n) = 1;
else
xm(n) = -1;
end
end


figure;
plot(t, xm);
xlabel('t (s)');
ylabel('x_m(t)');
title('ΣΔ modulisani signal');
ylim([-1.35 1.35])
grid on;


sigma = 0.45;
xc = xm + sigma*randn(size(xm));

figure;
plot(t,xc);
grid on;
xlabel('t (s)'); 
ylabel('x_c(t)');
title('Signal nakon AWGN kanala');

N = 200;
fc = 0.1;
b = fir1(N,fc);
xd = filter(b,1,xc);

figure;
plot(t,xd,'k'); 
grid on;
hold on;

plot(t,x,'r');
grid on;
xlabel('t (s)'); 
ylabel('Amplituda');
title('Izlaz filtera i ulazni signal');